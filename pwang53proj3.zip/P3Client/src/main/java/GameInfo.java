import java.io.Serializable;

public class GameInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	int p1Points = 0;
	int p2Points = 0;
	String p1Choice;
	String p2Choice;
	String choice = "Please make your choice";
	String word;
	Boolean ifAgain = false;
	Boolean have2Players = false;;
}