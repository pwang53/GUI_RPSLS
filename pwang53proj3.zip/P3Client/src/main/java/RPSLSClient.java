//reference: from professor GUIServer.java
//Peiqi Wang
//UIN: 669106127
//Description: This is project 3 of CS 342 Software Design
//			   The aim is to connect server and multi-client
//			   Clients can play the game and pass information
//
//			   ***However, I didn't finish that although work for
//				4 days from the day to the night.
//             Hope I will have solution code and learn better
//		       about this project.****


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class RPSLSClient extends Application{
	//Components needed to create start GUI
	BorderPane root;
	VBox vbox1;
	HBox h_l_t_portNumber;
	HBox h_l_t_ipAddress;
	TextField t_portNumber;
	TextField t_ipAddress;
	Label l_portNumber;
	Label l_ipAddress;
	Button btn_connectToServer;
	HashMap<String, Scene> sceneMap;
	Scene startScene;
	static int socketNumber;
	static String ipAddress;
	ClientConnect clientConnection;
	ClientConnect c2;
	ObjectOutputStream out;
	ObjectInputStream in;
	ArrayList<String> list = new ArrayList<String>();
	//static GameInfo info;
	
	//Components needed to create game GUI
	Button btn_print, btn_send;
	static Button btn_rock;
	static Button btn_scissors;
	static Button btn_paper;
	static Button btn_lizard;
	static Button btn_spock;
	static Button btn_playAgain;
	static Button btn_quit;
	Label point;
	HBox hbox1;
	HBox hbox2;
	VBox vbox2;
	String choice;
	static ListView<String> listItems;
	int click = 0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		//Create First Scene
		//Initialize root
		root = new BorderPane();
		
		//Initialize textField portNumber and ipAddress
		t_portNumber = new TextField("Type your port number.");
		t_ipAddress = new TextField("127.0.0.1");
		
		//Initialize button conncetToServer
		btn_connectToServer = new Button("Connect to Server");
		btn_connectToServer.setAlignment(Pos.CENTER);
		
		//Initialize two labels
		l_portNumber = new Label("Port Number : ");
		l_ipAddress = new Label("IP Address :     ");
		l_portNumber.setStyle("-fx-font-size: 20;");
		l_ipAddress.setStyle("-fx-font-size: 20;");
		
		//Add l_portNumber and t_portNumber into Hbox1
		h_l_t_portNumber = new HBox(20, l_portNumber, t_portNumber);
		h_l_t_portNumber.setAlignment(Pos.CENTER);
		
		//Add l_ipAddress and t_ipAddress into Hbox1
		h_l_t_ipAddress = new HBox(20, l_ipAddress, t_ipAddress);
		h_l_t_ipAddress.setAlignment(Pos.CENTER);
		
		//Initialize vbox1
		vbox1 = new VBox(50, h_l_t_portNumber, h_l_t_ipAddress, btn_connectToServer);
		vbox1.setAlignment(Pos.CENTER);
		
		//set root's padding, color and add the vbox1
		root.setPadding(new Insets(60));
		root.setTop(vbox1);
		root.setBackground(new Background(new BackgroundFill(Color.CHOCOLATE, CornerRadii.EMPTY, Insets.EMPTY)));
		
		//Click Button, change scene
		btn_connectToServer.setOnAction(e-> {
											socketNumber = Integer.parseInt(t_portNumber.getText());
											ipAddress = t_ipAddress.getText();
											primaryStage.setScene(sceneMap.get("client"));
											clientConnection = new ClientConnect(data->{
												Platform.runLater(()-> {listItems.getItems().add(data.toString());});
												list.add(data.toString());
											});
											clientConnection.start();
											});
		
		//Use Hash Map to store the science
		sceneMap = new HashMap<String, Scene>();
		sceneMap.put("client",  createClientGui());
		
		//
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			public void handle(WindowEvent t) {
				Platform.exit();
				System.exit(0);
			}
		});
		
		//To kill all threads after click the exit button
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {

			@Override
			public void handle(WindowEvent event) {
				Platform.exit();
				System.exit(0);
			}
		});
		
		//set title
		primaryStage.setTitle("RPSLS Client");
		
		startScene = new Scene(root,500,300);
		primaryStage.setScene(startScene);
		primaryStage.show();
	}
	
	//Create the Client Player GUI
	public Scene createClientGui() {
		//Create button and label their name
		btn_rock = new Button("Rock");
		btn_paper = new Button("Paper");
		btn_scissors = new Button("Scissors");
		btn_lizard = new Button("Lizard");
		btn_spock = new Button("Spock");
		btn_playAgain = new Button("Play Again");
		btn_quit = new Button("Quit");
		btn_send = new Button("Send");
		btn_print = new Button("Print Score");
		
		//set play again, quit and result disable as first
		btn_playAgain.setDisable(true);
		btn_quit.setDisable(true);
		
		//Play Again action
		btn_playAgain.setOnAction(e->{
			//s = clientConnection.getResult();
			//result.setText("p1Points: " + s.p1Points + " p2Points" + s.p2Points);
			clientConnection.send("Again");
			enableButtons();
			btn_send.setDisable(false);
			btn_playAgain.setDisable(true);
			btn_quit.setDisable(true);
		});
		
		//Quit button action
		btn_quit.setOnAction(e-> {
			Platform.exit();
		});
		
		//Rock button action
		btn_rock.setOnAction(e-> {
			choice = "Rock";
			listItems.getItems().add("You choose **" + choice + "**.\n" + "Click Send Button if you finally decide your choice.");
		});
		
		//Scissors button action
		btn_scissors.setOnAction(e-> {
			choice = "Scissors";
			listItems.getItems().add("You choose **" + choice + "**.\n" + "Click Send Button if you finally decide your choice.");
		});
		
		//Paper button action
		btn_paper.setOnAction(e-> {
			choice = "Paper";
			listItems.getItems().add("You choose **" + choice + "**.\n" + "Click Send Button if you finally decide your choice.");
		});
		
		//Lizard button action
		btn_lizard.setOnAction(e-> {
			choice = "Lizard";
			listItems.getItems().add("You choose **" + choice + "**.\n" + "Click Send Button if you finally decide your choice.");
		});
		
		//Spock button action
		btn_spock.setOnAction(e-> {
			choice = "Spock";
			listItems.getItems().add("You choose **" + choice + "**.\n" + "Click Send Button if you finally decide your choice.");
		});
		
		//Send button action
		btn_send.setOnAction(e-> {
			clientConnection.send(choice);
			listItems.getItems().add("Send Successfully. Please wait for the result!");
			disableButtons();
			btn_send.setDisable(true);
			btn_playAgain.setDisable(false);
			btn_quit.setDisable(false);		
		});
		
		btn_print.setOnAction(e-> {
			for(int i = 0; i < list.size(); i++) {
		
			listItems.getItems().add(list.get(i));
			}
		});
		
		//Creat list view
		listItems = new ListView<String>();
		
		//Create label to show point
		point = new Label("Your points: ");
		point.setStyle("-fx-font-size: 20;");	
		
		//Create hbox
		hbox1 = new HBox(20, btn_rock, btn_scissors, btn_paper, btn_lizard, btn_spock,  btn_send);
		hbox1.setAlignment(Pos.CENTER);
		
		//Create hbox2 for button quit and play again
		hbox2 = new HBox(20, btn_playAgain, btn_quit, btn_print);
		hbox2.setAlignment(Pos.CENTER);
		
		//Create vbox and add hbox into vbox
		vbox2 = new VBox(50, hbox1, hbox2, listItems);
		vbox2.setAlignment(Pos.CENTER);
		
		//Create Pane
		BorderPane pane = new BorderPane();
		pane.setPadding(new Insets(70));
		
		//Add vbox into pane and set pane's background color
		pane.setCenter(vbox2);
		pane.setBackground(new Background(new BackgroundFill(Color.CHOCOLATE, CornerRadii.EMPTY, Insets.EMPTY)));
		
		//Return scene
		return new Scene(pane, 800, 500);
	}
	
	//Get the socket number from user input which can be used as port number
	public static Integer getSocketNumber() {
		System.out.println(socketNumber);
		
		return socketNumber;
	}
	
	//Get user input and used for IP Address for socket conncection 
	public static String getIPAddress() {
		System.out.println(ipAddress);
		
		return ipAddress;
	}
	
	
	public static void disableButtons() {
		btn_paper.setDisable(true);
		btn_scissors.setDisable(true);
		btn_lizard.setDisable(true);
		btn_spock.setDisable(true);
		btn_rock.setDisable(true);
	}
	
	public static void enableButtons() {
		btn_playAgain.setDisable(false);
		btn_quit.setDisable(false);
		btn_paper.setDisable(false);
		btn_scissors.setDisable(false);
		btn_lizard.setDisable(false);
		btn_spock.setDisable(false);
		btn_rock.setDisable(false);
	}
}
