//reference: professor client.java
//Peiqi Wang
//UIN: 669106127
//Description: This is project 3 of CS 342 Software Design
//			   The aim is to connect server and multi-client
//			   Clients can play the game and pass information
//
//			   ***However, I didn't finish that although work for
//				4 days from the day to the night.
//             Hope I will have solution code and learn better
//		       about this project.****

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;

public class ClientConnect extends Thread {
	//initial socket
	Socket socketClient;
	//initial out and in
	ObjectOutputStream out;
	ObjectInputStream in;
	//GameInfo info = new GameInfo();
	private Consumer<Serializable> callback;
	
	ClientConnect(Consumer<Serializable> call){
		callback = call;
	}
	
	public void run() {
		try {
			//set socket
			socketClient = new Socket(RPSLSClient.getIPAddress(), RPSLSClient.getSocketNumber());
			//set in and out
			out = new ObjectOutputStream(socketClient.getOutputStream());
			in = new ObjectInputStream(socketClient.getInputStream());
			socketClient.setTcpNoDelay(true);
		}catch(Exception e) {e.printStackTrace();}
		
		
		while(true) {
			try {
				GameInfo temp = new GameInfo();
				temp = (GameInfo) in.readObject();
				callback.accept(temp.word);

			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	//send the object game information
	public void send(String data){
		
		try {
				if(data.equals("Again")) {
					GameInfo temp1 = new GameInfo();
					temp1.ifAgain = true;
					out.writeObject(temp1);
				}
				else {
				GameInfo temp2 = new GameInfo();
				temp2.choice = data;
				out.writeObject(temp2);
				System.out.println(temp2.choice);
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
