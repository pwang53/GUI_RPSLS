//Test for p3Client
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ClientTest {

	//test socket
	@Test
	void testSocket() {
		ClientConnect client = new ClientConnect(null);
		assertEquals("ClientConnect", client.getClass().getName());
	}
	//test game info
	@Test
	void testGameInfo() {
		GameInfo info = new GameInfo();
		assertEquals("GameInfo", info.getClass().getName());
	}
	
	//test socket number
	@Test
	void testSocketNumber() {
		RPSLSClient client = new RPSLSClient();
		client.socketNumber = 5555;
		assertEquals(5555,RPSLSClient.getSocketNumber());
	}
	
	//test ip address
	@Test
	void testIPAddress() {
		RPSLSClient client = new RPSLSClient();
		client.ipAddress = "127.0.0.1";
		assertEquals("127.0.0.1", RPSLSClient.getIPAddress());
	}
	
}
