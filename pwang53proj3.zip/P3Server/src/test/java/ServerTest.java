//Test for p3Server
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ServerTest {
	//test game info
	@Test
	void testGameInfo() {
		GameInfo info = new GameInfo();
		assertEquals("GameInfo", info.getClass().getName());
	}
	//test socket
	@Test
	void testSocket() {
		ServerConnect server = new ServerConnect(null);
		assertEquals("ServerConnect", server.getClass().getName());
	}
	//test client
	@Test
	void testClients() {
		ServerConnect server = new ServerConnect(null);
		assertEquals("java.util.ArrayList", server.clients.getClass().getName());
	}

	//test who won -- p1
	@Test
	void testWhoWon() {
		String who = GameLogic.whoWon("Paper", "Rock");
		assertEquals("p1", who);
	}
	//test who won -- draw 
	@Test
	void testWhoWon2() {
		String who = GameLogic.whoWon("Paper", "Paper");
		assertEquals("draw", who);
	}
	//test who won -- p2 
	@Test
	void testWhoWon3() {
		String who = GameLogic.whoWon("Rock", "Paper");
		assertEquals("p2", who);
	}
}


