//reference: from professor server.java
//Peiqi Wang
//UIN: 669106127
//Description: This is project 3 of CS 342 Software Design
//			   The aim is to connect server and multi-client
//			   Clients can play the game and pass information
//
//			   ***However, I didn't finish that although work for
//				4 days from the day to the night.
//             Hope I will have solution code and learn better
//		       about this project.****

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;

//Class begin
public class ServerConnect {
	int count = 1;				//use for count client number
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();   //array to store clients
	private Consumer<Serializable> callback;						   //get callback information
	TheServer server;													//create server
	GameInfo info = new GameInfo();										//set game information
	//GameInfo info2 = new GameInfo();
	String play = "Play";
	String wait = "Wait";
	ArrayList<String> list = new ArrayList<String>();
	
	//Constructor
	ServerConnect(Consumer<Serializable> call){
		
		callback = call;
		server = new TheServer();
		server.start();      //start method
	}
	
	
	//Server
	class TheServer extends Thread{
		
		public void run() {
			//create socket
			try(ServerSocket mysocket = new ServerSocket(RPSLSServer.getSocketNumber())){
		    System.out.println("Server is waiting for a client!");
			
		    while(true) {
		    	//create client and add them
				ClientThread c = new ClientThread(mysocket.accept(), count);
				//callback.accept("Port: " + RPSLSServer.getSocketNumber());
				callback.accept("client has connected to server: " + "client #" + count);
				clients.add(c);
				c.start();

				count++;
				
			    }
			}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			}//end of while
		}
	
	//Client Thread
	class ClientThread extends Thread{
			Socket connection;			//create socket
			int count;					//use for count number
			ObjectInputStream in;		//receive input
			ObjectOutputStream out;		//send output
			int number;					
			//GameInfo game;
			String again;
			
			//Constructor
			ClientThread(Socket s, int count){
				this.connection = s;
				this.count = count;	
				//game = new GameInfo();
				again  = "Again";
				if(this.count % 2 == 1) {
					this.number = 1;
				}
				else if(this.count % 2 == 0){
					this.number = 2;
				}
			}
			
			//update Clients with output gameinfo
			public void updateClients(GameInfo gameinfo) {
				for(int i = 0; i< clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
						t.out.writeObject(gameinfo);
					} catch(Exception e) {}
				}
			}
			
			//run
			public void run(){

				//get input and output
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}
				
				//Make a temp object to pass the infomation
				GameInfo temp = new GameInfo();
				temp.word = "Attention: You are the Client #" + count + "\n" + "You will be the Player #" + number;
				try {
					clients.get(count - 1).out.writeObject(temp);
				} catch (IOException e) {
					e.printStackTrace();
				}
				
				 while(true) {
					    try {
					    	GameLogic logic = new GameLogic();
					    	
					    	//read the input object and store into game
					    	GameInfo game = (GameInfo) in.readObject();
					    	
					    	
					    	

					    	//game.p1Choice = logic.choose();
					    	System.out.println(game.choice);
					    	System.out.println(game.ifAgain);
					    	
					    	
					    	if(this.number ==1 ) {
					    		
					    		
					    		if(game.ifAgain == true) {
					    			GameInfo temp2 = info;
					    			info = new GameInfo();
					    			info.p1Points = temp2.p1Points;
					    			info.p2Points = temp2.p2Points;
					    		}
					    		else {
					    		info.p1Choice = game.choice;
					    		callback.accept("player 1 choose " + info.p1Choice);
					    		}
					    	}
					    	
					    	if(this.number == 2) {
					    		if(game.ifAgain == true) {
					    			GameInfo temp2 = info;
					    			info = new GameInfo();
					    			info.p1Points = temp2.p1Points;
					    			info.p2Points = temp2.p2Points;
					    		}
					    		else {
					    		info.p2Choice = game.choice;
					    		callback.accept("player 2 choose " + info.p2Choice);
					    		}
					    	}
					    	
					    	if(info.p1Choice != null && info.p2Choice != null) {
					    		if(GameLogic.whoWon(info.p1Choice,info.p2Choice).equals("p1")) {
					    			info.p1Points ++;
					    			info.word = "Player 1 wins." + "\n"
					    						+ "Player 1: " + info.p1Choice + "  " + "Player 2: " + info.p2Choice
					    						+ "\n" + info.p1Points + " - " + info.p2Points;
					    		}
					    	
					    		if(GameLogic.whoWon(info.p1Choice,info.p2Choice).equals("p2")) {
					    			info.p2Points ++;
					    			info.word = "Player 2 wins." + "\n"
				    						+ "Player 1: " + info.p1Choice + "  " + "Player 2: " + info.p2Choice
				    						+ "\n" + info.p1Points + " - " + info.p2Points;
					    		}
					    		
					    		if(GameLogic.whoWon(info.p1Choice,info.p2Choice).equals("draw")) {
					    			info.word = "Draw" + "\n"
				    						+ "Player 1: " + info.p1Choice + "  " + "Player 2: " + info.p2Choice
				    						+ "\n" + info.p1Points + " - " + info.p2Points;
					    		}
					    		updateClients(info);
					    		
					    	}else {
					    		callback.accept("Wait for another player's choice");
					    		
					    	}
					    	
					    	//show out the points information
					    	callback.accept("Server received: " +  "p1: " + info.p1Choice + " p2: " + info.p2Choice);
					    	callback.accept("Points: " + info.p1Points + " --- " + info.p2Points);
					    
					    	
					    	System.out.println(info.p1Choice);
					    	
					    	
					    	}
					    catch(Exception e) {
					    	//if close, print out
					    	callback.accept("OOOOPPs...Something wrong with the socket from client: " + count + "....closing down!");
					    	GameInfo gameinfo2 = new GameInfo();
					    	gameinfo2.word = "Client #" + count + " has left the server!";
					    	updateClients(gameinfo2);
					    	clients.remove(this);
					    	break;
					    }
					}
				}//end of run

		}//end of client thread
	

	}
