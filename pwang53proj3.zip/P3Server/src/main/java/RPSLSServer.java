//reference: from professor GUIServer.java
//Peiqi Wang
//UIN: 669106127
//Description: This is project 3 of CS 342 Software Design
//			   The aim is to connect server and multi-client
//			   Clients can play the game and pass information
//
//			   ***However, I didn't finish that although work for
//				4 days from the day to the night.
//             Hope I will have solution code and learn better
//		       about this project.****

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.function.Consumer;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class RPSLSServer extends Application{
	//Components needed to create GUI
	BorderPane root;
	TextField t_portNumber;
	Button btn_turnOn;
	HashMap<String, Scene> changeScene;
	Scene startScene;
	VBox vbox1;
	Label l_portNumber;
	HBox h_l_t_portNumber;
	ListView<String> listItems;
	static int socketNumber;
	ServerConnect serverConnection;
	static GameInfo information = new GameInfo();
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
		//System.out.println(2 % 2);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		//Create First Scene
		//Initialize root
		root = new BorderPane();
		
		//Initialize textField portNumber and ipAddress
		t_portNumber = new TextField("Type your port number.");
		
		//Initialize button conncetToServer
		btn_turnOn = new Button("Turn on the server");
		btn_turnOn.setAlignment(Pos.CENTER);
		
		//Initialize two labels
		l_portNumber = new Label("Port Number : ");
		l_portNumber.setStyle("-fx-font-size: 20;");
		
		//Add l_portNumber and t_portNumber into Hbox1
		h_l_t_portNumber = new HBox(20, l_portNumber, t_portNumber);
		h_l_t_portNumber.setAlignment(Pos.CENTER);	
		
		//Initialize vbox1
		vbox1 = new VBox(50, h_l_t_portNumber, btn_turnOn);
		vbox1.setAlignment(Pos.CENTER);
		
		//set root's padding, color and add the vbox1
		root.setPadding(new Insets(60));
		root.setTop(vbox1);
		root.setBackground(new Background(new BackgroundFill(Color.CHOCOLATE, CornerRadii.EMPTY, Insets.EMPTY)));
		
		//Use Hash Map to store the science
		changeScene = new HashMap<String, Scene>();
		changeScene.put("server",  createServerGui());
		
		
		//Click Button to set the socket number and  change scene
		btn_turnOn.setOnAction(e-> {
			//if user doesn't input the integer, will let them type again
			try {
				socketNumber = Integer.parseInt(t_portNumber.getText());
				primaryStage.setScene(changeScene.get("server"));
				serverConnection = new ServerConnect(data -> {
					Platform.runLater(()->{
						listItems.getItems().add(data.toString());
						
					});
				});
			}catch(Exception event) {
				t_portNumber.setText("Must be INT. TRY AGAIN");
				socketNumber = 0;
			}
		}); 
		
		//To kill all threads after click the exit button
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {

			@Override
			public void handle(WindowEvent event) {
				Platform.exit();
				System.exit(0);
			}
		});
		
		primaryStage.setTitle("RPSLS Server");
		
		startScene = new Scene(root);
		primaryStage.setScene(startScene);
		primaryStage.show();
	}

	//Create the Client Player GUI
	public Scene createServerGui() {
		//Create pane
		BorderPane pane = new BorderPane();
		pane.setPadding(new Insets(70));
		
		//Initialize the list view
		listItems = new ListView<String>();
		
		//Add list view into pane
		pane.setCenter(listItems);
		//Return scene
		return new Scene(pane, 500, 400);
	}
	
	//Get the socket number from user input which can be used as port number
	public static Integer getSocketNumber() {
		System.out.println(socketNumber);
		
		return socketNumber;
	}

	public static GameInfo getGameInfo() {
		return information;
	}

	public static Boolean setGameBoolean(Boolean a) {
		information.have2Players = a;
		return a;
	}
	

}
