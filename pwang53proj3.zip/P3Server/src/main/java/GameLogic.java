import java.util.Random;

public class GameLogic {
	//function to check who won
	public static String whoWon(String p1Choice, String p2Choice) {
			//result.setText("Who won" + p1Choice + " " + p2Choice);
			
			//condition of p1 is paper
			if(p1Choice.equals("Paper")) {
				if(p2Choice.equals("Rock") || p2Choice.equals("Spock")) {
					return "p1";
				}else if(p2Choice.equals("Scissors") ||p2Choice.equals("Lizard")) {
					return "p2";
				}else {
					return "draw";
				}	
			}
			
			//condition of p1 is scissors
			else if(p1Choice.equals("Scissors")) {
				if(p2Choice.equals("Paper") || p2Choice.equals("Lizard")) {
					return "p1";
				}else if(p2Choice.equals("Spock") ||p2Choice.equals("Rock")) {
					return "p2";
				}else {
					return "draw";
				}	
			}
			//condition of p1 is rock
			else if(p1Choice.equals("Rock")) {
				if(p2Choice.equals("Lizard") || p2Choice.equals("Scissors")) {
					return "p1";
				}else if(p2Choice.equals("Paper") ||p2Choice.equals("Spock")) {
					return "p2";
				}else {
					return "draw";
				}	
			}
			//condition of p1 is lizard
			else if(p1Choice.equals("Lizard")) {
				if(p2Choice.equals("Spock") || p2Choice.equals("Paper")) {
					return "p1";
				}else if(p2Choice.equals("Scissors") ||p2Choice.equals("Rock")) {
					return "p2";
				}else {
					return "draw";
				}	
			}
			//condition of p1 is spock
			else if(p1Choice.equals("Spock")) {
				if(p2Choice.equals("Scissors") || p2Choice.equals("Rock")) {
					return "p1";
				}else if(p2Choice.equals("Lizard") ||p2Choice.equals("Paper")) {
					return "p2";
				}else {
					return "draw";
				}	
			}
			return "ERROR";
	}
	
}
